package DBConnect;

import java.sql.*;
import java.util.*;
import java.io.*;




public class JOConnection {
    public static Connection conn;
    public static Statement stmt;
    public static ResultSet rslt;


public static void JConnect() throws  ClassNotFoundException, SQLException {

String username ="hr"; 
String password ="hr"; 

Class.forName("oracle.jdbc.OracleDriver");
conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:orcl","hr","hr");
stmt = conn.createStatement();

}


}